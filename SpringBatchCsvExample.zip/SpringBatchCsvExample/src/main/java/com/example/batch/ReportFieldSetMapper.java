package com.example.batch;

import org.springframework.batch.item.file.mapping.FieldSetMapper;
import org.springframework.batch.item.file.transform.FieldSet;
import org.springframework.validation.BindException;

public class ReportFieldSetMapper implements FieldSetMapper<Report> {


	public Report mapFieldSet(FieldSet fieldSet) throws BindException {

		Report report = new Report();
		report.setTexte(fieldSet.readString("texte"));	
		report.setCount("");

		return report;

	}
}
