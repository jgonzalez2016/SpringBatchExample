package com.example.batch;

import org.springframework.batch.item.ItemProcessor;

//run before writing
public class CustomItemProcessor implements ItemProcessor<Report, Report> {

	public Report process(Report item) throws Exception {
		//count characters from the input file not including spaces
		int charsCount = 0;
		int wordsCount = 0;

		String tmpStr = item.getTexte();
		if (!tmpStr.equalsIgnoreCase("")) {
			String replaceAll = tmpStr.replaceAll("\\s+", "");
			charsCount += replaceAll.length();
			wordsCount += tmpStr.split(" ").length;
		}

		item.setCount("Total characters: " + charsCount + ", total words: " + wordsCount);

		return item;

	}

}
